# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 15:17:26 2019

@author: Sonia
"""

import pandas as pd
import numpy as np
import os

def eyeTrackerFeatures():
    
    
    directory = "C:\\Users\\Vishesh\\Desktop\\Sonia\\"
    studyGroup = "Study_2_Group_1" + "\\Sensor Data\\csv\\"
    fileNames = os.listdir(directory + studyGroup)
    for fileName in fileNames:
        allData = directory + studyGroup + fileName
        dt = pd.read_csv(allData, encoding='latin-1') 
    
        data = dt.loc[39:dt.shape[0]].values
        data = pd.DataFrame(data=data[1:,0:], columns=data[0,0:])  
   
        saveFile = directory + studyGroup +  fileName.split('.')[0] + "_" + "eyeData.csv"
        data.to_csv(saveFile)
    

    return data


def main():
    
    eyeTrackerFeatures()
    
    
if __name__ == '__main__':
    main()

