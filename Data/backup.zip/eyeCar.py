#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 24 17:09:56 2019

@author: sonia
"""
import pandas as pd
import numpy as np

from sklearn.cluster import KMeans
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from videos import videos
from participants import participants

from objMethod import ObjMethod

import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')


class eyeCar:
    
    def __init__(self, independentFile, dependentFile, hazardousFile):
        """
            initialize the state with the first video
        """
        self.independentFile = independentFile
        self.dependentFile = dependentFile
        self.hazardousFile = hazardousFile
        
        self.videos = videos()
        
        self.participants = participants()
        self.participants.initalParticipant()
        
        self.state = None
        self.action = None
        self.hazardous = None
        self.reward = None
        
        self.hazardousFrame = self.videos.hazardousFrame
        self.hazardousState = {participant: 0 for participant in self.participants.allParticipants}
        self.scoreIV = {participant: 0 for participant in self.participants.allParticipants}
        self.scoreDV = {participant: 0 for participant in self.participants.allParticipants}
        self.valueState = {participant: 0 for participant in self.participants.allParticipants} 
        self.validate = {participant: 0 for participant in self.participants.allParticipants}
        self.reward = {participant: 0 for participant in self.participants.allParticipants}
        
        self.rewardParam = 0.1
        self.alpha = 0.1
        self.gamma = 1
        self.participants.allParticipants
        
    def calculateIndScore(self, participant):
        """
            calculate the independent variable value by 
            age + gender + environment + weather + day + driving experience
        """
        
        independentValue = pd.read_csv(self.independentFile)
        slcVideos = self.videos.allVideos
        print(participant)
        iValues = independentValue.loc[(independentValue['ID'] == participant)]# & (independentValue['Video'] in slcVideos).any()]
        
        indValue = {}
        indValue = {video: {'age': iValues[iValues['Video'] == video]['Age'], 
                        'gender': iValues[iValues['Video'] == video]['Gender'], 
                        'weather': iValues[iValues['Video'] == video]['Weather'], 
                        'day': iValues[iValues['Video'] == video]['Time'],
                        'driving experience': iValues[iValues['Video'] == video]['Driving Experience'],
                        'posInRow': iValues[iValues['Video'] == video]['posInRow']} for video in slcVideos}                      
        return indValue;

    def calculateDepScore(self, participant):
        """
            in each frame of the video what is the value of
            gaze + pupil size + distance + fixation + fttp + car's speed 
        """
        dependentValue = pd.read_csv(self.dependentFile)
        slcVideos = self.videos.allVideos
        dValues = dependentValue.loc[dependentValue['participant'] == participant]
        depValue = {}
        
        for video in slcVideos:
            frames = dValues[dValues['stimulusName'] == video]['frame']
            frameDict = {}
            if len(frames) > 0:
                for frame in frames:
                    frameDict[frame] = {'frame': frame, 
                                        'gazeX': dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['GazeX'].iat[0], 
                                        'gazeY':dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['GazeY'].iat[0], 
                                        'pupilLeft':dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['pupilLeft'].iat[0], 
                                        'pupilRight': dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['pupilRight'].iat[0],
                                        'DistanceLeft': dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['DistanceLeft'].iat[0], 
                                        'DistanceRight':dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['DistanceRight'].iat[0], 
                                        'FixationSeq': dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['FixationSeq'].iat[0], 
                                        'FixationDuration': dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['FixationDuration'].iat[0], 
                                        'study':dValues[(dValues['stimulusName'] == video) & (dValues['frame'] == frame)]['study'].iat[0]}
                depValue[video] = {}
                depValue[video] = frameDict
            else:
                depValue[video] = {}
                
                
        return depValue;

    def calculateStateValue(self):
        """
            calculate the value of state by scoreIV, scoreDV + which video + place of video on row + group
        """        
        particpants = self.participants.allParticipants
        
        scoreIV = { participant:self.calculateIndScore(participant) for participant in particpants}
        scoreDV = { participant:self.calculateDepScore(participant) for participant in particpants}
#        
        self.scoreIV = scoreIV
        self.scoreDV = scoreDV
#        
#        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
#        objMethod = ObjMethod(objDir)
#        
#        scoreIV = objMethod.load_obj("scoreIV")
#        scoreDV = objMethod.load_obj("scoreDV")
#        self.scoreIV = scoreIV
#        self.scoreDV = scoreDV
        
        self.valueState = { participant:{'scoreIV': scoreIV.get(participant), 'scoreDV': scoreDV.get(participant)} for participant in particpants}
        
        return self.valueState
    
    def calcualteState(self):
        """
            initial the value of state for each participant
        """ 
        state = self.calculateStateValue()
        self.state = state
        objDir = "C:/Users/Group/Documents/SAMII/eyeCar-master/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        objMethod.save_obj(self.state, "state")
        
#        self.state = objMethod.load_obj("state")
        
       
    
    def caclulateAction(self,participant):
        """
            this is a boolean value if the agent look at the the hazardous
            it should retun the frame number + duration of hit on that frame
        """
        dependentValue = pd.read_csv(self.dependentFile)
        slcVideos = self.videos.allVideos
        vAction = dependentValue.loc[dependentValue['participant'] == participant]
        
        actionValue = {}
        frameDict = {}
        for video in slcVideos:
            frames = vAction[vAction['stimulusName'] == video]['frame']
            for frame in frames:
                frameDict[frame] = {'frame': frame, 
                                    'FixationDuration': vAction[(vAction['stimulusName'] == video) & (vAction['frame'] == frame)]['FixationDuration'], 
                                    'study':vAction[(vAction['stimulusName'] == video) & (vAction['frame'] == frame)]['study']}
                if video in actionValue.keys():
                    actionValue[video].append(frameDict)
                else:
                    actionValue[video] = []
                    actionValue[video].append(frameDict) 
        
        return actionValue;
    
    def actionValue(self):
        """
            calculate the value of action for each participant
        """
        particpants = self.participants.allParticipants    
        self.action = { participant:self.caclulateAction(participant) for participant in particpants}
        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)      
        objMethod.save_obj(self.action, "action")
#        self.action = objMethod.load_obj("action")
    
    def loadHazardous(self, participant):
        """
            this shows the value of participant duration of hazardous situation
        """


        hazardousFile = pd.read_csv(self.hazardousFile)
        slcVideos = self.videos.allVideos
        vHazardous = hazardousFile.loc[(hazardousFile['participant'] == participant)]
        hazardousValue = {video: {'aoiDuration': vHazardous.loc[vHazardous['stimulusName'] == video]['AOI Total Duration (ms)'],
                                  'visit': vHazardous.loc[vHazardous['stimulusName'] == video]['Respondent ratio-G'],
                                  'ttff': vHazardous.loc[vHazardous['stimulusName'] == video]['TTFF-F (ms)'],
                                  'timeSpent': vHazardous.loc[vHazardous['stimulusName'] == video]['Time spent-G (ms)'],
                                  'fixationCount': vHazardous.loc[vHazardous['stimulusName'] == video]['Fixations Count'],
                                  'hitTime': vHazardous.loc[vHazardous['stimulusName'] == video]['Hit time-G (ms)'],
                                  'tsG': vHazardous.loc[vHazardous['stimulusName'] == video]['Time spent-G (%)'],
                                  'avgFixDuration': vHazardous.loc[vHazardous['stimulusName'] == video]['Average Fixations Duration (ms)'] } for video in slcVideos}     
        
        return hazardousValue;
    
    def rewardValue(self):
        """
            this is a [0-1] value if the agent look at the hazardous (smaller framenumber) and look at 
            the hazardous in longer time we assign more reward to that participant.
        """
      
        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        self.action = objMethod.load_obj("action")
        
        videos = self.videos
        action = self.action
        rewards = self.reward
        validate = self.validate
      
#        hazardousFrame = self.videos.hazardousFrame
        particpants = self.participants.allParticipants    
        self.hazardous = { participant:self.loadHazardous(participant) for participant in particpants}
        hazardous = self.hazardous
        for participant in action.keys():
            print(participant)
            for video in action[participant].keys():
                if len(hazardous[participant][video]['visit']) != 0:
                    if hazardous[participant][video]['visit'].iat[0] != 0:
                        timeLatency = hazardous[participant][video]['avgFixDuration'].iat[0] #np.divide(hazardous[participant][video]['ffD'].iat[0], hazardous[participant][video]['aoiDuration'].iat[0])
                        if rewards[participant] == 0:
                            rewards[participant] = []
                            rewards[participant].append({video: timeLatency})
                        else:
                            rewards[participant].append({video: timeLatency})
                    else: 
                        if rewards[participant] == 0:
                            rewards[participant] = []
                            rewards[participant].append({video: -1})
                        else:
                            rewards[participant].append({video: -1})
                else:
                    if rewards[participant] == 0:
                            rewards[participant] = []
                            rewards[participant].append({video: -1})
                    else:
                        rewards[participant].append({video: -1})
                    
                        
        self.reward = rewards
        self.validate = validate
        
        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        objMethod.save_obj(self.reward, "reward")
    
    def pattern(self):
        """
            save the user's pattern based on each frame in each video
            Should consider two types of pattern 
                1. frame by frame for each user (it is just the sequence of value for the dependent values and the independent values are constant for each video)
                2. vide by video in each group
                3. group by group
        """
        
        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        state = objMethod.load_obj("state")
        action = objMethod.load_obj("action")
        reward = objMethod.load_obj("reward")
        
        
#        videos = []
#        rewards = []
#        for participant in reward.keys():
#            tmp1 = [list(r.values()) for r in reward[participant]]
#            rewards = [val for sublist in tmp1 for val in sublist]
#            tmp2 = [list(r.keys()) for r in reward[participant]]
#            videos = [val for sublist in tmp2 for val in sublist]
#            rewards = [0 if x==-1 else x for x in rewards]
#            rewards = [-x if x<0 else x for x in rewards]
#            plt.figure(figsize=(10,5))
#            plt.plot(videos, rewards, 'bo')
#            plt.show()
#            data

        import random
        from operator import itemgetter
        videos = self.videos.allVideos
        self.videos.hazardousFrameFun()
        hazardousFrame = self.videos.hazardousFrame
        data = []
        particpants = self.participants.allParticipants 
        dataDist = { participant:[] for participant in particpants}
        cnt = 0
        rParam = 0
        nParam = 0
        hParam = 0
        rndVar = 0
        vCnt = 0
        for participant in reward.keys():
            dExp = state[participant]['scoreIV']['Day_Rain_High_1']['driving experience']
            cnt = cnt + 1
            nwDict = dict((key,d[key]) for d in reward[participant] for key in d)
            print(participant)
            for video in videos:
                print(video)
                if "Rain" in video:
                    rParam = 3
                else:
                    rParam = 1
                if "Night" in video:
                    nParam = 2
                else:
                    nParam = 1
                if "High" in video:
                    hParam = 2.5
                else:
                    hParam = 1
                weight = rParam*hParam*nParam
                
                if video in nwDict:
                    
                    distanceLeft =  dict((key,d[key]['DistanceLeft'].iat[0]) for d in state[participant]['scoreDV'][video] for key in d)
                    distanceRight =  dict((key,d[key]['DistanceRight'].iat[0]) for d in state[participant]['scoreDV'][video] for key in d)
                    
                    stFrame = hazardousFrame[video]['startFrame'].iat[0]
                    endFrame = hazardousFrame[video]['endFrame'].iat[0]
                    frames = distanceLeft.keys()
                    distance = []
                    for frame in frames:
                        distance.append(np.mean([distanceLeft[frame], distanceRight[frame]]))
                        dTemp = {'x': frame , 'y': np.mean([distanceLeft[frame], distanceRight[frame]])/10, 
                                 's': np.round(np.mean([distanceLeft[frame], distanceRight[frame]])), 
                                 'color': videos.index(video) + 1, 
                                 'sFrame': stFrame,
                                 'eFrame': endFrame,
                                 'participant': participant }
                        dataDist[participant].append(dTemp)
                   
                    vTemp = {'x': videos.index(video) + 1, 'y': (weight*np.abs(nwDict[video]))/dExp, 's': (np.mean(distance)), 'color': cnt }
                        
                    rndVar =np.mean(distance)*(random.randint(2,3)/2)
                else:
                    vTemp = {'x': videos.index(video) + 1, 'y': (weight*rndVar)/dExp, 's':(rndVar), 'color': cnt }
                data.append(vTemp)
        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        objMethod.save_obj(dataDist, "dataDist")
        import json
        with open('data.txt', 'w') as outfile:
            json.dump(data, outfile)
        with open('datadist.txt', 'w') as outfile:
            json.dump(dataDist, outfile)
        
        
        
    def distPattern(self):
        """
            each individual has their own pattern of looking at the monitor we
            will check that one here
        """
        
        objDir = "C:/Users/Vishesh/Desktop/Sonia/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        dataDist = objMethod.load_obj("dataDist")
                
        videos = self.videos.allVideos
        
        
        for video in videos:
            vDist = []
            for participant in dataDist.keys():
                pDist = dataDist[participant]
                vDist.append([item for item in pDist if item["color"] == videos.index(video)+1])
            vDist =  [item for sublist in vDist for item in sublist]
            import json
            with open('data-'+video+'.txt', 'w') as outfile:
                json.dump(vDist, outfile)
        
        
        
    def irlComponent(self):
        """
            save the user's pattern based on each frame in each video
            Should consider two types of pattern 
                1. frame by frame for each user (it is just the sequence of value for the dependent values and the independent values are constant for each video)
                2. vide by video in each group
                3. group by group
        """
        
        objDir = "C:/Users/Group/Documents/SAMII/eyeCar-master/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        state = objMethod.load_obj("state")
        
        reward = objMethod.load_obj("reward")
        dependentValue = pd.read_csv(self.dependentFile)
        particpants = self.participants.allParticipants
        videos = self.videos.allVideos
        self.videos.hazardousFrameFun()
        hazardousFrame = self.videos.hazardousFrame 
        
        irlAction = {}
        irlVideo = {}
        irlState = []
        irlPstate = {}
        for p in particpants:
            for v in videos:
                if v in state[p]['scoreDV'].keys():
                    for f in state[p]['scoreDV'][v].keys():
                        if p in irlAction.keys():
                            if v in irlAction[p].keys():
                                if f in irlAction[p][v].keys():
                                    irlAction[p][v][f] = 0 if  np.isnan(state[p]['scoreDV'][v][f]['FixationDuration']) == True else 1
                                else:
                                    irlAction[p][v][f] = 0
                                    irlAction[p][v][f] = 0 if  np.isnan(state[p]['scoreDV'][v][f]['FixationDuration']) == True else 1
                            else:
                                irlAction[p][v] = {}
                                irlAction[p][v] = {f:0}
                        else:
                            irlAction[p] = {}
                            irlAction[p] = {v:{}}
                            irlAction[p][v] = {f: 0}
                            irlAction[p][v][f] = 0 if  np.isnan(state[p]['scoreDV'][v][f]['FixationDuration']) == True else 1
                    fixationDuration =  dict((d,state[p]['scoreDV'][v][d]['FixationDuration']) for d in state[p]['scoreDV'][v])
                    gazeX =   dict((d,state[p]['scoreDV'][v][d]['gazeX']) for d in state[p]['scoreDV'][v])
                    gazeY =  dict((d,state[p]['scoreDV'][v][d]['gazeY']) for d in state[p]['scoreDV'][v])
                    study =  dict((d,state[p]['scoreDV'][v][d]['study']) for d in state[p]['scoreDV'][v])
                    distance = dict((d,(state[p]['scoreDV'][v][d]['DistanceRight']+state[p]['scoreDV'][v][d]['DistanceLeft'])/2) for d in state[p]['scoreDV'][v])
                    pupil =  dict((d,(state[p]['scoreDV'][v][d]['pupilRight']+state[p]['scoreDV'][v][d]['pupilLeft'])/2) for d in state[p]['scoreDV'][v])
                    
                    irlVideo[v] = {}
                    irlVideo[v] = {'video': v, 'fixationDuration': fixationDuration, 'gazeX': gazeX, 'gazeY': gazeY, 'distance': distance, 'pupil': pupil, 'study': study}
                    if p in irlPstate.keys():
                        irlPstate[p].append({v: irlVideo[v]})
                    else:
                        irlPstate[p] = []
                        irlPstate[p].append({v: irlVideo[v]})
                    print("test")
                    
            
        
        
        objMethod.save_obj(irlAction, "irlAction")
        objMethod.save_obj(irlPstate, "irlState")
        
        
        
    def irlReward(self):
        """
            use the deep neuarl network for reward functions.
            the input can be
                1. all states and the output be the reward of each different action which is two actions
                2. all states and all the actions and output is the reward of the     
        """
        
        objDir = "C:/Users/Group/Documents/SAMII/eyeCar-master/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        
        irlAction = objMethod.load_obj("irlAction")
        irlState = objMethod.load_obj("irlState")
        #### Report every step
        participants = self.participants.allParticipants
        videos = self.videos.allVideos
        
        autoInput = pd.DataFrame(columns = range(450))
        i = 0
        for p in participants:
            for v in videos:
                tmp = dict((key,d[key]) for d in irlState[p] for key in d)
                lenData = len([v for k,v in tmp[v]['fixationDuration'].items()])
                print(lenData)
                if lenData == 0:
                    autoInput.loc[i] = [np.random.randint(0,1) for n in range(450)]
                else:
                    if lenData < 450:
                        autoInput.loc[i] = [v for k,v in tmp[v]['fixationDuration'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['gazeX'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['gazeY'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['distance'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['pupil'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                    else:
                        autoInput.loc[i] = [v for k,v in tmp[v]['fixationDuration'].items()][:450]
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['gazeX'].items()][:450]
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['gazeY'].items()][:450]
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['distance'].items()][:450]
                        i = i + 1
                        autoInput.loc[i] = [v for k,v in tmp[v]['pupil'].items()][:450]
                        
                i = i + 1
                    ##you should creat two dimention array with 450 as features and row is number of videos
        autoInput = autoInput.fillna(0)    
        autoInput.to_csv("autoInput.csv")
        print("test")
        
    #K means Clustering 
    def doKmeans(self, X, nclust=2):
        """
            cluster the data
        """
        
        model = KMeans(nclust)
        model.fit(X)
        clust_labels = model.predict(X)
        cent = model.cluster_centers_
        
        return (clust_labels, cent)

     
    def pupilKmean(self):
        
        """
            we would like to see if the pupil size is changing over changing of light, and weather conditions
        """
        objDir = "C:/Users/Group/Documents/SAMII/eyeCar-master/eyeCar-master/Data/InputData/"
        objMethod = ObjMethod(objDir)
        
        irlState = objMethod.load_obj("irlState")
        
        import json
        with open('irlState.json', 'w') as json_file:
            json.dump(irlState, json_file)
        
        participants = self.participants.allParticipants
        videos = self.videos.allVideos
        
        pupil = pd.DataFrame(columns = range(450))
        study = pd.DataFrame(columns = range(450))
        rainTag = []
        nightTag = []
        highTag = []
        i = 0
        for p in participants:
            for v in videos:
                tmp = dict((key,d[key]) for d in irlState[p] for key in d)
                lenData = len([v for k,v in tmp[v]['pupil'].items()])
                if lenData == 0:
                    pupil.loc[i] = [np.random.randint(0,1) for n in range(450)]
                else:
                    if lenData < 450:
                        pupil.loc[i] = [v for k,v in tmp[v]['pupil'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                        study.loc[i] = [v for k,v in tmp[v]['study'].items()].append([np.random.randint(0,1) for n in range(lenData,450)])
                    else:
                        pupil.loc[i] = [v for k,v in tmp[v]['pupil'].items()][:450]
                        study.loc[i] = [v for k,v in tmp[v]['study'].items()][:450]
                        tmpRain = 1 if "Rain" == tmp[v]['video'].split("_")[1] else 0
                        rainTag.append(tmpRain)
                        tmpNight = 1 if "Night" == tmp[v]['video'].split("_")[0] else 0
                        nightTag.append(tmpNight)
                        tmpHigh = 1 if "High" == tmp[v]['video'].split("_")[2] else 0
                        highTag.append(tmpHigh)
                       
                i = i + 1
                
        study = study.fillna(0)
        pupil = pupil.fillna(0)  
        
        # Create scaler: scaler
        scaler = StandardScaler()
       
        pupil = pupil.dropna(how='all',axis=0)
        study = study.dropna(how = 'all', axis = 0)
        pupil = pupil.loc[~(pupil==0).all(axis=1)]
        study = study.loc[~(study==0).all(axis=1)]
        
        pupil['mean'] = pupil.mean(axis=1)
        samples = np.array(pupil['mean'])
        
        Sum_of_squared_distances = []
        K = range(1,15)
        for k in K:
            km = KMeans(n_clusters=k)
             # Create pipeline: pipeline
#            pipeline = make_pipeline(scaler,km)
            # Fit the pipeline to samples
            km.fit(samples.reshape(-1, 1))
            Sum_of_squared_distances.append(km.inertia_)
            
            
        plt.plot(K, Sum_of_squared_distances, 'bx-')
        plt.xlabel('k')
        plt.ylabel('Sum_of_squared_distances')
        plt.title('Elbow Method For Optimal k')
        plt.show()
        
        
        clust_labels, cent = self.doKmeans(samples.reshape(-1,1), 4)
            
        kmeans = pd.DataFrame(clust_labels)
        samples = pd.DataFrame(samples, columns = ["pupil"])
        samples.insert((samples.shape[1]),'kmeans',kmeans)
        
        fig = plt.figure()
        ax = fig.add_subplot(111)
        scatter = ax.scatter(range(450),pupil.iloc[0],s=50)
        ax.set_title('K-Means Clustering')
        ax.set_xlabel('pupil size')
        
        plt.colorbar(scatter)
        plt.show()
        
        
        ######
        rain = pd.DataFrame(rainTag)
        fig = plt.figure()
        ax = fig.add_subplot(111)
        scatter = ax.scatter(samples['pupil'],len(samples['pupil']) * [1], c=rain[0],s=50)
        ax.set_title('K-Means Clustering - Rain(1)/Sunny(0)')
        ax.set_xlabel('pupil size')
        
        plt.colorbar(scatter)
        plt.show()
        
        ######
        night = pd.DataFrame(nightTag)
        fig = plt.figure()
        ax = fig.add_subplot(111)
        scatter = ax.scatter(samples['pupil'],len(samples['pupil']) * [1], c=night[0],s=50)
        ax.set_title('K-Means Clustering - Night(1)/Day(0)')
        ax.set_xlabel('pupil size')
        
        plt.colorbar(scatter)
        plt.show()
        
        ######
        high = pd.DataFrame(highTag)
        fig = plt.figure()
        ax = fig.add_subplot(111)
        scatter = ax.scatter(samples['pupil'],len(samples['pupil']) * [1], c=high[0],s=50)
        ax.set_title('K-Means Clustering - Highway(1)/Town(0) ')
        ax.set_xlabel('pupil size')
        
        plt.colorbar(scatter)
        plt.show()
        
        
        
       
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    